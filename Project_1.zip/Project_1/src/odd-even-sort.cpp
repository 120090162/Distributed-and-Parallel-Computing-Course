#include <odd-even-sort.hpp>
#include <mpi.h>
#include <iostream>
#include <vector>

namespace sort {
    using namespace std::chrono;

    Context::Context(int &argc, char **&argv) : argc(argc), argv(argv) {
        MPI_Init(&argc, &argv);
    }

    Context::~Context() {
        MPI_Finalize();
    }

    std::unique_ptr<Information> Context::mpi_sort(Element *begin, Element *end) const {
        int res;
        int rank;
        int proc_num;
        int whole_size;
        std::unique_ptr<Information> information{};

        res = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        if (MPI_SUCCESS != res) {
            throw std::runtime_error("failed to get MPI world rank");
        }
        res = MPI_Comm_size(MPI_COMM_WORLD, &proc_num);
        if (MPI_SUCCESS != res) {
            throw std::runtime_error("failed to get MPI world size");
        }

        /* --------------------------------------------------------------------------------------- */
        /* Part 1: store some basic info of processes */
        if (0 == rank) {
            whole_size = end - begin;
            information = std::make_unique<Information>();
            information->length = end - begin;
            res = MPI_Comm_size(MPI_COMM_WORLD, &information->num_of_proc);
            if (MPI_SUCCESS != res) {
                throw std::runtime_error("failed to get MPI world size");
            };
            information->argc = argc;
            for (auto i = 0; i < argc; ++i) {
                information->argv.push_back(argv[i]);
            }
            information->start = high_resolution_clock::now();
        }
        /* --------------------------------------------------------------------------------------- */
        /* Part 2: Do some preparation for sorting */
    
        /* Broad-cast the size of problem to all processes */
        MPI_Bcast(&whole_size, 1, MPI_INT, 0, MPI_COMM_WORLD);

        /* create a new communicator to deal with the situation that: 
        there are less number than the number of processors */
        MPI_Group world_group;
        MPI_Comm_group(MPI_COMM_WORLD, & world_group);
        if (whole_size < proc_num){
            proc_num = whole_size;
        }
        int ranks[proc_num];
        for (int i = 0; i < proc_num; i ++){
            ranks[i] = i;
        }
        MPI_Group new_group;
        MPI_Group_incl(world_group, proc_num, ranks, &new_group);
        MPI_Comm new_comm;
        MPI_Comm_create_group(MPI_COMM_WORLD, new_group, 0, &new_comm);

        /* set the processors which won't be used to -1 */
        if (rank >= whole_size){
            rank = -1;
        }

        /* --------------------------------------------------------------------------------------- */
        {
            /* Part 3: Distribute tasks to each processors */
            MPI_Request send_req;
            int sub_size_array[proc_num];    /* number of tasks of each rank process */
            int send_batch_length = (whole_size / proc_num);      /* the avarage size assigned to each processors */
            /* determine the number of task to be assigned to each processes */
            int remain_batch_length = (whole_size % proc_num);   /* > 0 when number of tasks cannot be fully divided by number of processors */
            int count = send_batch_length;
            sub_size_array[0] = send_batch_length;
            for (int des = 1; des < proc_num; des++){
                /* when the number of task cannot be fully divided by num of processors: 
                   assign the one remaining task to this processor */
                if (remain_batch_length > 0) {
                    sub_size_array[des] = send_batch_length + 1;  
                    remain_batch_length -= 1;
                }
                else{
                    sub_size_array[des] = send_batch_length;
                }
            }
            Element data[whole_size];
            int displs[proc_num];
            displs[0] = 0;
            for (int i = 0; i < proc_num-1; i++){
                displs[i+1] = sub_size_array[i] + displs[i];
            }
            if (rank >= 0){
                MPI_Scatterv(begin, sub_size_array, displs, MPI_LONG, data, sub_size_array[rank], MPI_LONG, 0, new_comm);
            }
            

            int sub_size;
            int start_rank;
            if (rank > 0) {
                start_rank = displs[rank];
                sub_size = sub_size_array[rank];
            }    
            /* start the odd-even-sort! */
            int odd = 1;
            if (0 == rank){
                int quit = 0;   /* an indicator for jumping out of the while loop */
                while(true){
                    Element origin[send_batch_length];      /* which will be compared after one iteration of sorting to indicate whether the array change or not*/
                    for (int i = 0; i < send_batch_length; i++){
                        origin[i] = data[i];
                    }
                    /* judge whehter its adjcent processor will send data to be compared */
                    /* if yes, it will recv the data, and compare it with the number in the last position, and send the larger one back */
                    if ((send_batch_length-1) % 2 != odd && proc_num > 1){  
                        Element recv = 0;
                        MPI_Recv(&recv, 1, MPI_LONG, rank+1, 1, new_comm, MPI_STATUS_IGNORE);
                        Element Bigger;
                        if (recv < data[send_batch_length-1]){ // if left is bigger than right
                            Bigger = data[send_batch_length-1];
                            data[send_batch_length-1] = recv;
                        }
                        else{
                            Bigger = recv;
                        }
                        MPI_Isend(&Bigger, 1, MPI_LONG, rank+1, 2, new_comm, &send_req);
                    }
                    /* for the data not on the boundary position (no need to recv and send) */
                    /* do the normal odd-even sort just in their porcessor (without being exchange with next number in next processor)*/
                    for (int j = 2-odd; j < send_batch_length; j+=2){
                        if (data[j-1] > data[j]){
                            Element temp = data[j-1];
                            data[j-1] = data[j];
                            data[j] = temp;
                        }
                    }
                    /* transform iteration between sorting base on odd rank and base on even rank */
                    if (odd){
                        odd = 0;
                    }else{
                        odd = 1;}
                    int cons = 1;
                    /* check whether the array unchanged after sorting */
                    for (int i = 0; i < send_batch_length; i++){
                        if (origin[i] != data[i]){
                            cons = 0;
                        }
                    }
                    int result = 0;
                    MPI_Barrier(new_comm); 
                    /* check whether all the numbers' postion unchanged after sorting */
                    MPI_Allreduce(&cons, &result, 1, MPI_INT, MPI_LAND, new_comm);
                    MPI_Barrier(new_comm);
                    if (result == 1){
                        quit += 1;
                    }else{
                        quit = 0;}
                    /* if the all data's position keep unchanged after two times of iteration (both based on even and on odd) */
                    /* means sorting finished, break out of the while loop */
                    if (quit == 2){
                        break;
                    }
                } 
            }
            else{
                if (rank != -1){
                    int quit = 0;
                    while(true){
                        Element origin[sub_size];
                        for (int i = 0; i < sub_size; i++){
                            origin[i] = data[i];
                        }
                        /* judge whether it should send the data in the left boundary */
                        if (start_rank % 2 == odd){
                            MPI_Isend(&(data[0]), 1, MPI_LONG, rank-1, 1, new_comm, &send_req);
                        }
                        /* recieve data in the right boundary, and send the bigger one back */
                        if ((start_rank+sub_size-1) % 2 != odd && rank != proc_num-1){
                            Element recv = 0;
                            MPI_Recv(&recv, 1, MPI_LONG, rank+1, 1, new_comm, MPI_STATUS_IGNORE);
                            Element Bigger;
                            if (recv < data[sub_size-1]){
                                Bigger = data[sub_size-1];
                                data[sub_size-1] = recv;
                            }
                            else{
                                Bigger = recv;
                            }
                            MPI_Isend(&Bigger, 1, MPI_LONG, rank+1, 2, new_comm, &send_req);
                        }
                        if (start_rank % 2 == odd){
                            MPI_Recv(&(data[0]), 1, MPI_LONG, rank-1, 2, new_comm, MPI_STATUS_IGNORE);
                        }
                        /* for the numbers not in the boundary (not involved compared with other number in other processor) */
                        /* just do the local odd-even sort */
                        for (int j = 1+odd; j < sub_size; j+=2){
                            if (data[j-1] > data[j]){
                                Element temp = data[j-1];
                                data[j-1] = data[j];
                                data[j] = temp;
                            }
                        }  
                        if (odd){
                            odd = 0;
                        }else{
                            odd = 1;}
                        int cons = 1;
                        /* check whether the numbers' position keep unchanged after one iteration of sorting */
                        for (int i = 0; i < sub_size; i++){
                            if (origin[i] != data[i]){
                                cons = 0;
                            }
                        }
                        int result = 0;
                        MPI_Barrier(new_comm);  
                        /* check whether all numbers in all the processors' position keep unchanged */
                        MPI_Allreduce(&cons, &result, 1, MPI_INT, MPI_LAND, new_comm);
                        MPI_Barrier(new_comm);
                        if (result == 1){
                            quit += 1;
                        }else{
                            quit = 0;}
                        /* if all the numbers' positon keep unchanged after two iteration of sorting (completely one iteration of odd-even sorting) */
                        /* means sorting finished, break from the while loop */
                        if (quit == 2){
                            break;
                        }
                    }
                }
            }
            if (rank >= 0){
                MPI_Gatherv(data, sub_size_array[rank], MPI_LONG, begin, sub_size_array, displs, MPI_LONG, 0, new_comm);
            }
        }

        if (0 == rank) {
            information->end = high_resolution_clock::now();
        }
        return information;
    }

    std::ostream &Context::print_information(const Information &info, std::ostream &output) {
        auto duration = info.end - info.start;
        auto duration_count = duration_cast<nanoseconds>(duration).count();
        auto mem_size = static_cast<double>(info.length) * sizeof(Element) / 1024.0 / 1024.0 / 1024.0;
        output << "input size: " << info.length << std::endl;
        output << "proc number: " << info.num_of_proc << std::endl;
        output << "duration (ns): " << duration_count << std::endl;
        output << "throughput (gb/s): " << mem_size / static_cast<double>(duration_count) * 1'000'000'000.0
               << std::endl;
        return output;
    }
}
