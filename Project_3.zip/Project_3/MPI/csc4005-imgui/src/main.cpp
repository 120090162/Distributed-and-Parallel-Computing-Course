#include <graphic/graphic.hpp>
#include <imgui_impl_sdl.h>
#include <cstring>
#include <nbody/body.hpp>
#include <mpi.h>
#include <chrono>

template <typename ...Args>
void UNUSED(Args&&... args [[maybe_unused]]) {}


int main(int argc, char **argv) {
    UNUSED(argc, argv);
    int rank;
    int num_processes;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_processes);
    if (rank == 0){
        static float gravity = 100;
        static float space = 800;
        static float radius = 5;
        static int bodies = 200;
        static float elapse = 0.10;
        static ImVec4 color = ImVec4(1.0f, 1.0f, 0.4f, 1.0f);
        static float max_mass = 10;
        static float current_space = space;
        static float current_max_mass = max_mass;
        static int current_bodies = bodies;

        BodyPool pool(static_cast<size_t>(bodies), space, max_mass); /* all the processes should declare a Bodypool here */
        graphic::GraphicContext context{"Assignment 3"};
    /* The root process mainly handel the initialization and painting, also, it participate the parallel computing together with other processes. */
        context.run([&](graphic::GraphicContext *context [[maybe_unused]], SDL_Window *) {
            auto io = ImGui::GetIO();
            ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f));
            ImGui::SetNextWindowSize(io.DisplaySize);
            ImGui::Begin("Assignment 2", nullptr,
                        ImGuiWindowFlags_NoMove
                        | ImGuiWindowFlags_NoCollapse
                        | ImGuiWindowFlags_NoTitleBar
                        | ImGuiWindowFlags_NoResize);
            ImDrawList *draw_list = ImGui::GetWindowDrawList();
            ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate,
                        ImGui::GetIO().Framerate);
            ImGui::DragFloat("Space", &current_space, 10, 200, 1600, "%f");
            ImGui::DragFloat("Gravity", &gravity, 0.5, 0, 1000, "%f");
            ImGui::DragFloat("Radius", &radius, 0.5, 2, 20, "%f");
            ImGui::DragInt("Bodies", &current_bodies, 1, 2, 100, "%d");
            ImGui::DragFloat("Elapse", &elapse, 0.001, 0.001, 10, "%f");
            ImGui::DragFloat("Max Mass", &current_max_mass, 0.5, 5, 100, "%f");
            ImGui::ColorEdit4("Color", &color.x);

            auto starting = std::chrono::high_resolution_clock::now();
            /* Part1: Broadcast the basic information about the problem from root process to other processes */
            MPI_Bcast(&gravity, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);      
            MPI_Bcast(&space, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&radius, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&bodies, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&elapse, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&max_mass, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_space, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_max_mass, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_bodies, 1, MPI_INT, 0, MPI_COMM_WORLD);

            /* update the current information of problem of if they change */
            if (current_space != space || current_bodies != bodies || current_max_mass != max_mass) {
                space = current_space;
                bodies = current_bodies;
                max_mass = current_max_mass;
                pool = BodyPool{static_cast<size_t>(bodies), space, max_mass};   /* Intialize the problems here, including mass, speed, positon. acceleration of bodies */
            }

            /* Part 2: Broadcast the states of bodies from root process to other processes */
            MPI_Bcast(&pool.x[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.y[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.vx[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.vy[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.ax[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.ay[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.m[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            {
                const ImVec2 p = ImGui::GetCursorScreenPos();

                /* doing the parallel computating (updating the state of bodies here) */
                pool.update_for_tick(elapse, gravity, space, radius);   

                MPI_Barrier(MPI_COMM_WORLD);   /* synchronize when all the processes finish their work */
                auto ending = std::chrono::high_resolution_clock::now();
                long local_time = duration_cast<std::chrono::nanoseconds>(ending - starting).count();
                std::cout <<"current bodies: " << current_bodies << " || duration time: " << local_time <<std::endl;
                
                /* the root process paint the results finally */ 
                for (size_t i = 0; i < pool.size(); ++i) {  
                    auto body = pool.get_body(i);
                    auto x = p.x + static_cast<float>(body.get_x());
                    auto y = p.y + static_cast<float>(body.get_y());
                    draw_list->AddCircleFilled(ImVec2(x, y), radius, ImColor{color});
                }
            }
            ImGui::End();
        });
    }
    else{  /* for other processes, they are incharge of recieving the information of problems, 
            states of bodies from root process, and performing the parallel computing (update the states of bodies) */
        while(1){
            float gravity;
            float space;
            float radius;
            int bodies;
            float elapse;
            float max_mass;
            float current_space;
            float current_max_mass;
            int current_bodies;
            /* recv basic information of problem from root process */
            MPI_Bcast(&gravity, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&space, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&radius, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&bodies, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&elapse, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&max_mass, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_space, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_max_mass, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&current_bodies, 1, MPI_INT, 0, MPI_COMM_WORLD);
            BodyPool pool(static_cast<size_t>(bodies), space, max_mass);   /* each process owns a pool */

            if (current_space != space || current_bodies != bodies || current_max_mass != max_mass) {
                space = current_space;
                bodies = current_bodies;
                max_mass = current_max_mass;
                pool = BodyPool{static_cast<size_t>(bodies), space, max_mass};   /* there is a randomlization here */
            }
            /* recv the state of bodies(postion, velocity, acceleration, mass) from root process */
            MPI_Bcast(&pool.x[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.y[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.vx[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.vy[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.ax[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.ay[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            MPI_Bcast(&pool.m[0], current_bodies, MPI_DOUBLE, 0, MPI_COMM_WORLD);
            
            /* performing the parallle computing to update the state of bodies */
            pool.update_for_tick(elapse, gravity, space, radius); 
            MPI_Barrier(MPI_COMM_WORLD);
        }
    }
}
