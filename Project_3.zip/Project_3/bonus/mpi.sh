#!/bin/bash
#SBATCH --account=csc4005
#SBATCH --partition=debug
#SBATCH --qos=normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --output=/pvfsmnt/119010249/csc4005-assignment-3/csc4005-assignment-3-MPI/csc4005-imgui/out.txt



echo "mainmode: " && /bin/hostname
xvfb-run -a mpirun /pvfsmnt/119010249/csc4005-assignment-3/csc4005-assignment-3-MPI/csc4005-imgui/build/csc4005_imgui 800