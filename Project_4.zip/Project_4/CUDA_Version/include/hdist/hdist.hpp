#pragma once

#include <vector>
#include <stdio.h> 

namespace hdist {

    __device__ enum class Algorithm : int {
        Jacobi = 0,
        Sor = 1
    };

    __device__ __host__ struct State {
        int room_size = 800;
        float block_size = 2;
        int source_x = room_size / 2;
        int source_y = room_size / 2;
        float source_temp = 100;
        float border_temp = 100;
        float tolerance = 0.02;
        float sor_constant = 4.0;
        Algorithm algo = hdist::Algorithm::Jacobi;

        // bool operator==(const State &that) const = default;
        __device__ __host__ bool operator!=(State &that){
            if (room_size != that.room_size) return true;
            if (block_size != that.block_size) return true;
            if (source_x != that.source_x) return true;
            if (source_y != that.source_y) return true;
            if (source_temp != that.source_temp) return true;
            if (border_temp != that.border_temp) return true;
            if (tolerance != that.tolerance) return true;
            if (sor_constant != that.sor_constant) return true;
            if (algo != that.algo) return true;
            return false;
        }
    };

    __device__ struct Alt {
    };

    __device__ constexpr static inline Alt alt{};

    __device__ __host__ struct Grid {
        double * data0;
        double * data1;
        size_t current_buffer = 0;
        size_t length;
        __device__ explicit Grid(size_t size,
                      double border_temp,
                      double source_temp,
                      size_t x,
                      size_t y){
                // : data0(size * size), data1(size * size), length(size) {
            data0 = (double*)malloc(sizeof(double)*size*size);
            data1 = (double*)malloc(sizeof(double)*size*size);
            length = size;
            for (int i = 0; i < length; i += 1) {
                for (int j = 0; j < length; j += 1) {
                    if (i == 0 || j == 0 || i == length - 1 || j == length - 1) {
                        this->get_element(i, j) = border_temp;
                    } else if (i == x && j == y) {
                        this->get_element(i, j) = source_temp;
                    } else {
                        this->get_element(i, j) = 0;
                    }
                }
            }
        }

        __device__ __host__ double* &get_current_buffer() {
            if (current_buffer == 0) return data0;
            return data1;
        }

        __device__ __host__ double &get_element(size_t first, size_t second){
            return get_current_buffer()[first * length + second];
        }

        __device__ __host__ double &get_element(Alt alt, size_t first, size_t second){
            return current_buffer == 1 ? data0[first * length + second] : data1[
                first * length + second];
        }

        __device__ void switch_buffer() {
            current_buffer = !current_buffer;
        }

        __device__ void destroy_buffer(){
            free(data0);
            free(data1);
        }
    };

    __device__ struct UpdateResult {
        bool stable;
        double temp;
    };

    __device__ UpdateResult update_single(size_t i, size_t j, Grid &grid, const State &state) {
        UpdateResult result{};
        if (i == 0 || j == 0 || i == state.room_size - 1 || j == state.room_size - 1) {
            result.temp = state.border_temp;
        } else if (i == state.source_x && j == state.source_y) {
            result.temp = state.source_temp;
        } else {
            auto sum = (grid.get_element(i+1, j) + grid.get_element(i-1, j) + grid.get_element(i, j+1) + grid.get_element(i, j-1));
            switch (state.algo) {
                case Algorithm::Jacobi:
                    result.temp = 0.25 * sum;
                    break;
                case Algorithm::Sor:
                    result.temp = grid.get_element(i, j) + (1.0 / state.sor_constant) * (sum - 4.0 * grid.get_element(i, j));
                    break;
            }
        }
        result.stable = std::fabs(grid.get_element(i, j) - result.temp) < state.tolerance;
        return result;
    }

    __device__ bool calculate(const State &state, Grid &grid, int NUM_THREAD, double * device_buffer) {
        bool stabilized = true;
        /* strip partition the problem */
        int rank = threadIdx.x;
        int assign = state.room_size / NUM_THREAD;
        int remain  = state.room_size % NUM_THREAD;
        int offset;
        if (rank < remain){
            offset = (rank)*(assign+1);
            assign += 1;
        }else offset = remain * (assign + 1) + (rank - remain) * assign;


        switch (state.algo) {
            case Algorithm::Jacobi:
                for (int i = offset; i < offset + assign; ++i) {
                    for (size_t j = 0; j < state.room_size; ++j) {
                        auto result = update_single(i, j, grid, state);
                        stabilized &= result.stable;
                        grid.get_element(alt, i, j) = result.temp;
                        device_buffer[i*state.room_size + j] = result.temp;   /* make a copy, which will be later memcpy to host memory */
                    }
                }
                grid.switch_buffer();
                break;
            case Algorithm::Sor:
                for (auto k : {0, 1}) {
                    for (int i = 0; i < offset+assign; i++) {
                        for (size_t j = 0; j < state.room_size; j++) {
                            if (k == ((i + j) & 1)) {
                                auto result = update_single(i, j, grid, state);
                                stabilized &= result.stable;
                                grid.get_element(alt, i, j) = result.temp;
                                device_buffer[i*state.room_size + j] = result.temp;
                            } else {
                                grid.get_element(alt, i, j) = grid.get_element(i, j);
                                device_buffer[i*state.room_size + j] = grid.get_element(i, j);
                            }
                        }
                    }
                    grid.switch_buffer();
                }
        }
        return stabilized;
    };


} // namespace hdist