#! /bin/bash
rm -rf build
mkdir build
cd build
source scl_source enable devtoolset-10
CC=gcc CXX=g++ cmake ..
make -j12