#include <graphic/graphic.hpp>
#include <imgui_impl_sdl.h>
#include <cstring>
#include <chrono>
#include <hdist/hdist.hpp>
#include <mpi.h>

#define NUM_THREAD 4     /* pre define that the number of threads for OpenMP program is 4 */

template<typename ...Args>
void UNUSED(Args &&... args [[maybe_unused]]) {}

ImColor temp_to_color(double temp) {
    auto value = static_cast<uint8_t>(temp / 100.0 * 255.0);
    return {value, 0, 255 - value};
}

int main(int argc, char **argv) {

    UNUSED(argc, argv);
    int first = 1;
    bool finished = false;
    int changed = 0;     /* to indicate whether the parameters have been changed or not */
    static hdist::State current_state, last_state;
    static std::chrono::high_resolution_clock::time_point begin, end, iter_begin, iter_end;
    static const char* algo_list[2] = { "jacobi", "sor" };
    auto grid = hdist::Grid{
            static_cast<size_t>(current_state.room_size),
            current_state.border_temp,
            current_state.source_temp,
            static_cast<size_t>(current_state.source_x),
            static_cast<size_t>(current_state.source_y)};
    int rank;
    int num_processes;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_processes);

    int * recvcount = (int*)malloc(sizeof(int)*num_processes);
    int * disp = (int*)malloc(sizeof(int)*num_processes);

    if (rank == 0){
        graphic::GraphicContext context{"Assignment 4"};
        context.run([&](graphic::GraphicContext *context [[maybe_unused]], SDL_Window *) {
            auto io = ImGui::GetIO();
            ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f));
            ImGui::SetNextWindowSize(io.DisplaySize);
            ImGui::Begin("Assignment 4", nullptr,
                        ImGuiWindowFlags_NoMove
                        | ImGuiWindowFlags_NoCollapse
                        | ImGuiWindowFlags_NoTitleBar
                        | ImGuiWindowFlags_NoResize);
            ImDrawList *draw_list = ImGui::GetWindowDrawList();
            ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate,
                        ImGui::GetIO().Framerate);
            ImGui::DragInt("Room Size", &current_state.room_size, 10, 200, 10000, "%d");
            ImGui::DragFloat("Block Size", &current_state.block_size, 0.01, 0.1, 10, "%f");
            ImGui::DragFloat("Source Temp", &current_state.source_temp, 0.1, 0, 1000, "%f");
            ImGui::DragFloat("Border Temp", &current_state.border_temp, 0.1, 0, 1000, "%f");
            ImGui::DragInt("Source X", &current_state.source_x, 1, 1, current_state.room_size - 2, "%d");
            ImGui::DragInt("Source Y", &current_state.source_y, 1, 1, current_state.room_size - 2, "%d");
            ImGui::DragFloat("Tolerance", &current_state.tolerance, 0.01, 0.01, 1, "%f");
            ImGui::ListBox("Algorithm", reinterpret_cast<int *>(&current_state.algo), algo_list, 2);

            if (current_state.algo == hdist::Algorithm::Sor) {
                ImGui::DragFloat("Sor Constant", &current_state.sor_constant, 0.01, 0.0, 20.0, "%f");
            }

            iter_begin = std::chrono::high_resolution_clock::now();
            if (current_state.room_size != last_state.room_size) {
                grid = hdist::Grid{
                        static_cast<size_t>(current_state.room_size),
                        current_state.border_temp,
                        current_state.source_temp,
                        static_cast<size_t>(current_state.source_x),
                        static_cast<size_t>(current_state.source_y)};
                first = 1;
            }

            if (current_state != last_state) {

                last_state = current_state;
                finished = false;
                changed = 1;
            }
            /* to indicate the other process whether it has been changed */
            MPI_Barrier(MPI_COMM_WORLD); 

            MPI_Bcast(&changed, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&first, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&finished, 1, MPI_CXX_BOOL, 0, MPI_COMM_WORLD);
            if (changed){
                changed = 0;
                MPI_Bcast(&current_state.room_size, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.block_size, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_x, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_y, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_temp, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.border_temp, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.tolerance, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.sor_constant, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.algo, 1, MPI_INT, 0, MPI_COMM_WORLD);
            }

            if (first) {         /* if first is true, means the room-size has been changed */
                first = 0;
                finished = false;
                begin = std::chrono::high_resolution_clock::now();
            }

            if (!finished) {
                /* partition the workload */
                int assign = current_state.room_size / num_processes;
                int remain  = current_state.room_size % num_processes;
                int offset;
                for (int i = 0; i < num_processes; i++){
                    if (i < remain){
                        recvcount[i] = (assign + 1) * current_state.room_size;
                        disp[i] = i * (assign + 1) * current_state.room_size;
                    }
                    else{
                        recvcount[i] = assign * current_state.room_size;
                        disp[i] = (remain * (assign + 1) + (i - remain) * assign) * current_state.room_size;
                    }
                }
                if (rank < remain){
                    offset = (rank)*(assign+1);
                    assign += 1;
                }else offset = remain * (assign + 1) + (rank - remain) * assign;

                finished = hdist::calculate(current_state, grid, offset, assign, recvcount, disp, NUM_THREAD);
                if (finished) end = std::chrono::high_resolution_clock::now();
            }
            else{
                std::cout << "stabelized in " << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count() << "ns" << std::endl;
                ImGui::Text("stabilized in %lld ns", std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count());
            }
            iter_end = std::chrono::high_resolution_clock::now();
            const ImVec2 p = ImGui::GetCursorScreenPos();
            float x = p.x + current_state.block_size, y = p.y + current_state.block_size;
            for (size_t i = 0; i < (size_t)current_state.room_size; ++i) {
                for (size_t j = 0; j < (size_t)current_state.room_size; ++j) {
                    auto temp = grid[{i, j}];
                    auto color = temp_to_color(temp);
                    draw_list->AddRectFilled(ImVec2(x, y), ImVec2(x + current_state.block_size, y + current_state.block_size), color);
                    y += current_state.block_size;
                }
                x += current_state.block_size;
                y = p.y + current_state.block_size;
            }
            ImGui::End();
        });
    }else{/* other processes execute this */
        while (1){    
            MPI_Barrier(MPI_COMM_WORLD); 

            MPI_Bcast(&changed, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&first, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&finished, 1, MPI_CXX_BOOL, 0, MPI_COMM_WORLD);
            if (changed){
                changed = 0;
                MPI_Bcast(&current_state.room_size, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.block_size, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_x, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_y, 1, MPI_INT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.source_temp, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.border_temp, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.tolerance, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.sor_constant, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);
                MPI_Bcast(&current_state.algo, 1, MPI_INT, 0, MPI_COMM_WORLD);
            }
            if (first){
                first = 0;
                grid = hdist::Grid{
                        static_cast<size_t>(current_state.room_size),
                        current_state.border_temp,
                        current_state.source_temp,
                        static_cast<size_t>(current_state.source_x),
                        static_cast<size_t>(current_state.source_y)};
            }

            /* partition the workload to processes */
            int assign = current_state.room_size / num_processes;
            int remain  = current_state.room_size % num_processes;
            int offset;
            for (int i = 0; i < num_processes; i++){
                if (i < remain){
                    recvcount[i] = (assign + 1) * current_state.room_size;
                    disp[i] = i * (assign + 1) * current_state.room_size;
                }
                else{
                    recvcount[i] = assign * current_state.room_size;
                    disp[i] = (remain * (assign + 1) + (i - remain) * assign) * current_state.room_size;
                }
            }
            if (rank < remain){
                offset = (rank)*(assign+1);
                assign += 1;
            }else offset = remain * (assign + 1) + (rank - remain) * assign;

            if (!finished){ /* if not finished, do the calcualtion */
                finished = hdist::calculate(current_state, grid, offset, assign, recvcount, disp, NUM_THREAD);
            }
        }
    }
    free(recvcount);
    free(disp);
}
